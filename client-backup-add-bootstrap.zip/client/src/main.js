// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import axios from 'axios'

import './assets/libs/bootstrap/dist/css/bootstrap.min.css';
import './assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js';
import VueFeather from 'vue-feather';
import 'bootstrap-table/dist/bootstrap-table.js'
import 'bootstrap-table/dist/themes/materialize/bootstrap-table-materialize.js'
import 'bootstrap-table/dist/extensions/export/bootstrap-table-export.js'
import 'bootstrap-table/dist/bootstrap-table.min.css'
//import BootstrapTable from 'bootstrap-table/dist/bootstrap-table-vue.js'

Vue.config.productionTip = false;
Vue.use(VueFeather);
//Vue.component('BootstrapTable', BootstrapTable);

const base = axios.create({
  baseURL: ''
})

Vue.prototype.$api = base

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
})
