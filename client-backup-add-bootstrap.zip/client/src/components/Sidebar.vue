<template>
  <nav class="navbar-vertical light navbar">
    <div class="nav-scroller">
      <!-- Brand logo -->
      <a class="navbar-brand" href="../index.html">
        <img src="../assets/images/garuda_circle.png" alt="" /> GarudaCBT
      </a>
      <hr>
      <!-- Navbar nav -->
      <ul class="navbar-nav flex-column" id="sideNavbar">
        <li class="nav-item">
          <router-link :to="{ name: 'dashboard'}" class="nav-link has-arrow active">
            <feather type="home" class="nav-icon icon-xs me-2"></feather>  Dashboard
          </router-link>
        </li>
        <!-- Master -->
        <li class="nav-item">
          <a class="nav-link has-arrow  collapsed " href="#!" data-bs-toggle="collapse" data-bs-target="#navMaster" aria-expanded="false" aria-controls="navMaster">
            <feather type="layers"
              class="nav-icon icon-xs me-2">
            </feather> Data Umum
          </a>

          <div id="navMaster" class="collapse " data-bs-parent="#sideNavbar">
            <ul class="nav flex-column">
              <li class="nav-item">
                <router-link :to="{ name: 'TahunPelajaran'}" class="nav-link">
                  <feather type="calendar" class="nav-icon icon-xs me-2"></feather> Tahun Pelajaran
                </router-link>
              </li>
              <li class="nav-item">
                <a class="nav-link " href="../pages/pricing.html">
                  Mata Pelajaran
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link has-arrow   "  href="../pages/settings.html" >
                  Jurusan
                </a>
              </li>
              <li class="nav-item">
                <router-link :to="{ name: 'Siswa'}" class="nav-link">
                  <feather type="users" class="nav-icon icon-xs me-2"></feather> Siswa
                </router-link>
              </li>
              <li class="nav-item">
                <router-link :to="{ name: 'Guru'}" class="nav-link">
                  <feather type="users" class="nav-icon icon-xs me-2"></feather> Guru
                </router-link>
              </li>
              <li class="nav-item">
                <a class="nav-link " href="../pages/billing.html">
                  Kelas
                </a>
              </li>
            </ul>
          </div>
        </li>

        <!-- Nav item -->
        <li class="nav-item">
          <div class="navbar-heading">Layouts & Pages</div>
        </li>
        <!-- Nav item -->
        <li class="nav-item">
          <a class="nav-link has-arrow  collapsed " href="#!" data-bs-toggle="collapse" data-bs-target="#navPages" aria-expanded="false" aria-controls="navPages">
            <feather
              type="layers"
              class="nav-icon icon-xs me-2">
            </feather> Pages
          </a>
          <div id="navPages" class="collapse " data-bs-parent="#sideNavbar">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link " href="../pages/profile.html">
                  Profile
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link has-arrow   "  href="../pages/settings.html" >
                  Settings
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link " href="../pages/billing.html">
                  Billing
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link " href="../pages/pricing.html">
                  Pricing
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link " href="../pages/404-error.html">
                  404 Error
                </a>
              </li>
            </ul>
          </div>
        </li>
        <!-- Nav item -->
        <li class="nav-item">
          <router-link :to="{name: 'Icons'}" class="nav-link " href="../pages/layout.htm">
            <feather type="image" class="nav-icon icon-xs me-2"></feather> Icons
          </router-link>
        </li>
        <li class="nav-item">
          <a class="nav-link has-arrow  collapsed " href="#!" data-bs-toggle="collapse" data-bs-target="#navAuthentication" aria-expanded="false" aria-controls="navAuthentication">
            <feather type="lock" class="nav-icon icon-xs me-2">
            </feather> Authentication
          </a>
          <div id="navAuthentication" class="collapse " data-bs-parent="#sideNavbar">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link " href="../pages/sign-in.html"> Sign In</a>
              </li>
              <li class="nav-item">
                <a class="nav-link  " href="../pages/sign-up.html"> Sign Up</a>
              </li>
              <li class="nav-item">
                <a class="nav-link " href="../pages/forget-password.html">
                  Forget Password
                </a>
              </li>
            </ul>
          </div>
        </li>
        <li class="nav-item">
          <a class="nav-link " href="../pages/layout.html">
            <feather type="sidebar" class="nav-icon icon-xs me-2"></feather>Layouts
          </a>
        </li>
        <!-- Nav item -->
        <li class="nav-item">
          <div class="navbar-heading">UI Components</div>
        </li>
        <!-- Nav item -->
        <li class="nav-item">
          <a class="nav-link has-arrow " href="../docs/accordions.html" >
            <feather type="package" class="nav-icon icon-xs me-2" >
            </feather>  Components
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link has-arrow  collapsed " href="#!" data-bs-toggle="collapse" data-bs-target="#navMenuLevel" aria-expanded="false" aria-controls="navMenuLevel">
            <feather type="corner-left-down"
              class="nav-icon icon-xs me-2">
            </feather> Menu Level
          </a>
          <div id="navMenuLevel" class="collapse " data-bs-parent="#sideNavbar">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link has-arrow " href="#!" data-bs-toggle="collapse" data-bs-target="#navMenuLevelSecond" aria-expanded="false" aria-controls="navMenuLevelSecond">
                  Two Level
                </a>
                <div id="navMenuLevelSecond" class="collapse" data-bs-parent="#navMenuLevel">
                  <ul class="nav flex-column">
                    <li class="nav-item">
                      <a class="nav-link " href="#!">  NavItem 1</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link " href="#!">  NavItem 2</a>
                    </li>
                  </ul>
                </div>
              </li>
              <li class="nav-item">
                <a class="nav-link has-arrow  collapsed  " href="#!" data-bs-toggle="collapse" data-bs-target="#navMenuLevelThree" aria-expanded="false" aria-controls="navMenuLevelThree">
                  Three Level
                </a>
                <div id="navMenuLevelThree" class="collapse " data-bs-parent="#navMenuLevel">
                  <ul class="nav flex-column">
                    <li class="nav-item">
                      <a class="nav-link  collapsed " href="#!" data-bs-toggle="collapse" data-bs-target="#navMenuLevelThreeOne" aria-expanded="false" aria-controls="navMenuLevelThreeOne">
                        NavItem 1
                      </a>
                      <div id="navMenuLevelThreeOne" class="collapse collapse " data-bs-parent="#navMenuLevelThree">
                        <ul class="nav flex-column">
                          <li class="nav-item">
                            <a class="nav-link " href="#!">
                              NavChild Item 1
                            </a>
                          </li>
                        </ul>
                      </div>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link " href="#!">  Nav Item 2</a>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
        </li>
        <!-- Nav item -->
        <li class="nav-item">
          <div class="navbar-heading">Documentation</div>
        </li>
        <!-- Nav item -->
        <li class="nav-item">
          <a class="nav-link has-arrow " href="../docs/index.html" >
            <feather type="clipboard" class="nav-icon icon-xs me-2" >
            </feather>  Docs
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link has-arrow " href="../docs/changelog.html" >
            <feather type="git-pull-request" class="nav-icon icon-xs me-2" >
            </feather>  Changelog
          </a>
        </li>
      </ul>
    </div>
  </nav>
</template>

<script>
  export default {
    name: "Sidebar"
  }
</script>

<style scoped>

</style>
