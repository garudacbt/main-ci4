<template>
    <h1>Siswa</h1>
</template>

<script>
    export default {
        name: "Siswa"
    }
</script>

<style scoped>

</style>
