import Vue from 'vue'
import Router from 'vue-router'

import HelloWorld from '@/components/HelloWorld'
import Books from '@/components/Books'
import PageNotFound from '../pages/PageNotFound'

import Admin from '../pages/admin/Admin'
import Dashboard from '../pages/admin/Dashboard'
import Guru from '../pages/admin/master/Guru'
import TahunPelajaran from '../pages/admin/master/TahunPelajaran'
import Siswa from '../pages/admin/master/Siswa'
import Icons from '../pages/Icons/Icons'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'HelloWorld',
      component: HelloWorld
    },
    {
      path: '/books',
      name: 'Books',
      component: Books
    },
    {
      path: '/admin',
      name: 'Admin',
      component: Admin,
      meta: { requiresToken: true },
      children: [
        {
          path: '',
          name: 'dashboard',
          component: Dashboard,
          // meta: { requiresToken: true }
        },
        {
          path: 'tahunpelajaran',
          name: 'TahunPelajaran',
          component: TahunPelajaran,
          meta: { requiresToken: true }
        },
        {
          path: 'siswa',
          name: 'Siswa',
          component: Siswa,
          meta: { requiresToken: true }
        },
        {
          path: 'guru',
          name: 'Guru',
          component: Guru,
          meta: { requiresToken: true }
        },
        {
          path: 'icons',
          name: 'Icons',
          component: Icons
        },
        /*
        {
          path: 'mal',
          name: 'mal',
          component: MalAdmin,
          meta: { requiresToken: true }
        },
        {
          path: 'infaq',
          name: 'infaq',
          component: InfaqAdmin,
          meta: { requiresToken: true }
        },
        {
          path: 'mustahik',
          name: 'mustahik',
          component: Mustahik,
          meta: { requiresToken: true }
        },
        {
          path: 'mustahik/:id',
          name: 'mustahikDetail',
          component: MustahikDetail,
          meta: { requiresToken: true }
        },
        {
          path: 'transaksi/zakat',
          name: 'transaksiZakat',
          component: TransaksiZakat,
          meta: { requiresToken: true }
        },
        {
          path: 'transaksi/infaq',
          name: 'transaksiInfaq',
          component: TransaksiInfaq,
          meta: { requiresToken: true }
        },
        {
          path: 'admins',
          name: 'admins',
          component: Admins,
          meta: { requiresToken: true }
        },
        */
      ]
    },
    { path: "*", component: PageNotFound }
  ]
})
